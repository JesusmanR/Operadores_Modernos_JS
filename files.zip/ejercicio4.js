/**
 * ejercicio4.js — Informe de estadísticas deportivas
 * estadisticas(jugadores)
 *   a. try...catch para verificar la estructura de datos
 *   b. destructuración profunda para obtener los puntos del primer jugador
 *   c. suma total de puntos con técnicas inmutables
 *   d. objeto con puntos del primero, puntos totales y lista inmutable
 */
import { hacerInmutable, esObjetoPlano } from "./utilidades.js";

export const jugadores = [
  { nombre: "Ana", stats: { puntos: 20, asistencias: 5 } },
  { nombre: "Luis", stats: { puntos: 15, asistencias: 7 } },
];

export function estadisticas(listaJugadores) {
  try {
    // a. Verificación de la estructura
    if (Array.isArray(listaJugadores) === false) {
      throw new Error("Los jugadores deben enviarse en un arreglo.");
    }
    if (listaJugadores.length === 0) {
      throw new Error("El arreglo de jugadores está vacío.");
    }

    for (let i = 0; i < listaJugadores.length; i++) {
      const jugador = listaJugadores[i];

      if (esObjetoPlano(jugador) === false) {
        throw new Error("El jugador en la posición " + i + " no es un objeto.");
      }
      if (typeof jugador.nombre !== "string" || jugador.nombre.trim() === "") {
        throw new Error("El jugador en la posición " + i + " no tiene nombre.");
      }
      if (esObjetoPlano(jugador.stats) === false) {
        throw new Error(
          "El jugador " + jugador.nombre + " no tiene el objeto stats."
        );
      }
      if (typeof jugador.stats.puntos !== "number" || isNaN(jugador.stats.puntos)) {
        throw new Error(
          "El jugador " + jugador.nombre + " no tiene puntos numéricos."
        );
      }
      if (
        typeof jugador.stats.asistencias !== "number" ||
        isNaN(jugador.stats.asistencias)
      ) {
        throw new Error(
          "El jugador " + jugador.nombre + " no tiene asistencias numéricas."
        );
      }
    }

    // b. Destructuración profunda del primer jugador
    const [
      {
        nombre: nombrePrimerJugador,
        stats: { puntos: puntosPrimerJugador },
      },
    ] = listaJugadores;

    // c. Suma total de puntos y copia inmutable de cada jugador
    let puntosTotales = 0;
    let asistenciasTotales = 0;
    const procesados = [];

    for (let i = 0; i < listaJugadores.length; i++) {
      const { nombre, stats } = listaJugadores[i];
      const { puntos, asistencias } = stats;

      puntosTotales += puntos;
      asistenciasTotales += asistencias;

      // Copia profunda con spread, sin tocar el objeto original
      procesados[i] = hacerInmutable({
        nombre: nombre,
        stats: hacerInmutable({ ...stats }),
      });
    }

    const promedioPuntos = Number(
      (puntosTotales / listaJugadores.length).toFixed(2)
    );

    // d. Objeto final inmutable
    return hacerInmutable({
      primerJugador: nombrePrimerJugador,
      puntosPrimerJugador: puntosPrimerJugador,
      puntosTotales: puntosTotales,
      asistenciasTotales: asistenciasTotales,
      promedioPuntos: promedioPuntos,
      jugadoresProcesados: hacerInmutable(procesados),
      totalJugadores: listaJugadores.length,
      validacion: true,
    });
  } catch (error) {
    return hacerInmutable({
      error: error.message,
      validacion: false,
    });
  }
}

export function ejecutarEjercicio4() {
  const opcion = prompt(
    "Ejercicio 4 — Estadísticas deportivas\n\n" +
      "1. Usar el equipo de ejemplo (Ana y Luis)\n" +
      "2. Ingresar jugadores manualmente\n" +
      "3. Provocar un error (estructura inválida)\n\n" +
      "Digite 1, 2 o 3:"
  );

  if (opcion === null) {
    return { cancelado: true };
  }

  let listaUsada = jugadores;

  if (opcion.trim() === "2") {
    const nuevos = [];
    let continuar = true;

    while (continuar) {
      const nombre = prompt(
        "Jugador " + (nuevos.length + 1) + " — nombre (deje vacío para terminar):"
      );

      if (nombre === null || nombre.trim() === "") {
        continuar = false;
      } else {
        const puntosTexto = prompt("Puntos de " + nombre.trim() + ":");
        const asistenciasTexto = prompt("Asistencias de " + nombre.trim() + ":");

        const puntos = puntosTexto === null ? NaN : Number(puntosTexto);
        const asistencias =
          asistenciasTexto === null ? NaN : Number(asistenciasTexto);

        nuevos[nuevos.length] = {
          nombre: nombre.trim(),
          stats: {
            puntos: isNaN(puntos) ? puntosTexto : puntos,
            asistencias: isNaN(asistencias) ? asistenciasTexto : asistencias,
          },
        };
      }
    }

    listaUsada = nuevos;
  } else if (opcion.trim() === "3") {
    listaUsada = "esto no es un arreglo de jugadores";
  }

  const informe = estadisticas(listaUsada);

  return {
    titulo: "Ejercicio 4 — Informe de estadísticas deportivas",
    listaOriginal: listaUsada,
    resultado: informe,
  };
}
