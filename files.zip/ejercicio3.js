/**
 * ejercicio3.js — Procesamiento de compras
 * procesarCompra(cliente, productos)
 *   a. try...catch para validar cliente {nombre, correo} y productos
 *   b. spread para crear un objeto nuevo con la información del cliente
 *   c. destructuración para separar el primer producto del resto
 *   d. informe con total de productos, precio total y primer producto
 */
import { hacerInmutable, esObjetoPlano } from "./utilidades.js";

export function procesarCompra(cliente, productos) {
  try {
    // a. Validación del cliente
    if (esObjetoPlano(cliente) === false) {
      throw new Error("El cliente debe ser un objeto.");
    }
    if (typeof cliente.nombre !== "string" || cliente.nombre.trim() === "") {
      throw new Error("El cliente debe tener un nombre válido.");
    }
    if (typeof cliente.correo !== "string" || cliente.correo.indexOf("@") === -1) {
      throw new Error("El cliente debe tener un correo válido.");
    }

    // Validación de la lista de productos
    if (Array.isArray(productos) === false) {
      throw new Error("Los productos deben enviarse en un arreglo.");
    }
    if (productos.length === 0) {
      throw new Error("Debe registrar al menos un producto.");
    }

    for (let i = 0; i < productos.length; i++) {
      const producto = productos[i];
      if (esObjetoPlano(producto) === false) {
        throw new Error("El producto en la posición " + i + " no es un objeto.");
      }
      if (typeof producto.nombre !== "string" || producto.nombre.trim() === "") {
        throw new Error("El producto en la posición " + i + " no tiene nombre.");
      }
      if (typeof producto.precio !== "number" || isNaN(producto.precio)) {
        throw new Error(
          "El producto en la posición " + i + " no tiene un precio numérico."
        );
      }
      if (producto.precio < 0) {
        throw new Error(
          "El producto en la posición " + i + " tiene un precio negativo."
        );
      }
    }

    // b. Spread: objeto nuevo con la información del cliente
    const clienteAmpliado = { ...cliente, fechaCompra: new Date().toLocaleString() };

    // c. Destructuración: primer producto separado del resto
    const [primerProducto, ...restoProductos] = productos;

    // d. Cálculo del precio total con ciclo for
    let precioTotal = 0;
    for (let i = 0; i < productos.length; i++) {
      precioTotal += productos[i].precio;
    }
    precioTotal = Number(precioTotal.toFixed(2));

    return hacerInmutable({
      cliente: hacerInmutable({ ...clienteAmpliado }),
      totalProductos: productos.length,
      precioTotal: precioTotal,
      primerProducto: hacerInmutable({ ...primerProducto }),
      productosRestantes: restoProductos.length,
      validacion: true,
    });
  } catch (error) {
    return hacerInmutable({
      error: error.message,
      validacion: false,
    });
  }
}

export function ejecutarEjercicio3() {
  const nombre = prompt("Ejercicio 3 — Nombre del cliente:");
  if (nombre === null) {
    return { cancelado: true };
  }

  const correo = prompt("Correo del cliente:");
  if (correo === null) {
    return { cancelado: true };
  }

  const productos = [];
  let continuar = true;

  while (continuar) {
    const nombreProducto = prompt(
      "Producto " + (productos.length + 1) + " — nombre (deje vacío para terminar):"
    );

    if (nombreProducto === null || nombreProducto.trim() === "") {
      continuar = false;
    } else {
      const precioTexto = prompt("Precio de " + nombreProducto.trim() + ":");
      const precio = precioTexto === null ? NaN : Number(precioTexto);

      productos[productos.length] = {
        nombre: nombreProducto.trim(),
        precio: isNaN(precio) ? precioTexto : precio,
      };
    }
  }

  const informe = procesarCompra({ nombre: nombre, correo: correo }, productos);

  return {
    titulo: "Ejercicio 3 — Procesamiento de compras",
    productosIngresados: productos,
    resultado: informe,
  };
}
