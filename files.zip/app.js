/**
 * app.js — Punto de entrada de la aplicación
 * Muestra un menú con prompt() y ejecuta el ejercicio seleccionado.
 * Si la opción no es válida, vuelve a solicitarla sin recargar la página.
 */
import {
  ejecutarEjercicio1,
  ejecutarEjercicio2,
  ejecutarEjercicio3,
  ejecutarEjercicio4,
  ejecutarEjercicio5,
} from "./modulos/index.js";

const MENU =
  "===== OPERADORES MODERNOS DE JAVASCRIPT =====\n\n" +
  "1. Sistema de registro académico\n" +
  "2. Fusión de catálogos digitales\n" +
  "3. Procesamiento de compras\n" +
  "4. Informe de estadísticas deportivas\n" +
  "5. Motor de configuración avanzada\n" +
  "0. Salir\n\n" +
  "Digite el número del ejercicio que desea ejecutar:";

const salida = document.getElementById("salida");

/**
 * Escribe un bloque de resultado en la página.
 */
function imprimir(texto, clase) {
  const bloque = document.createElement("div");
  bloque.className = "bloque " + (clase || "");
  bloque.textContent = texto;
  salida.appendChild(bloque);
  salida.scrollTop = salida.scrollHeight;
}

/**
 * Convierte cualquier resultado en texto legible.
 */
function formatear(valor) {
  return JSON.stringify(valor, null, 2);
}

/**
 * Muestra en pantalla y en consola lo que devolvió cada ejercicio.
 */
function mostrarResultado(datos) {
  if (datos === undefined || datos === null) {
    return;
  }

  if (datos.cancelado === true) {
    imprimir("Operación cancelada por el usuario.", "aviso");
    return;
  }

  imprimir(datos.titulo, "titulo");

  const resultado = datos.resultado;
  const huboError = resultado !== undefined && resultado.validacion === false;

  imprimir(formatear(datos), huboError ? "error" : "exito");
  console.log(datos.titulo, datos);
}

/**
 * Bucle principal del menú: se repite hasta que el usuario digite 0.
 * No requiere recargar la página para volver a pedir la opción.
 */
function iniciar() {
  let ejecutando = true;

  while (ejecutando) {
    const opcion = prompt(MENU);

    // El usuario presionó Cancelar
    if (opcion === null) {
      imprimir("Programa finalizado.", "aviso");
      ejecutando = false;
      continue;
    }

    const eleccion = opcion.trim();

    switch (eleccion) {
      case "1":
        mostrarResultado(ejecutarEjercicio1());
        break;

      case "2":
        mostrarResultado(ejecutarEjercicio2());
        break;

      case "3":
        mostrarResultado(ejecutarEjercicio3());
        break;

      case "4":
        mostrarResultado(ejecutarEjercicio4());
        break;

      case "5":
        mostrarResultado(ejecutarEjercicio5());
        break;

      case "0":
        imprimir("Programa finalizado. Gracias por usar la aplicación.", "aviso");
        ejecutando = false;
        break;

      default:
        // Opción inválida: se vuelve a mostrar el menú en la siguiente vuelta
        alert(
          'La opción "' + eleccion + '" no es válida.\n\n' +
            "Debe digitar un número entre 0 y 5."
        );
        imprimir('Opción inválida ingresada: "' + eleccion + '"', "error");
        break;
    }
  }
}

// Botón para volver a abrir el menú sin recargar la página
document.getElementById("btnMenu").addEventListener("click", iniciar);

// Botón para limpiar la salida
document.getElementById("btnLimpiar").addEventListener("click", function () {
  salida.innerHTML = "";
});

// Arranque automático al cargar la página
iniciar();
