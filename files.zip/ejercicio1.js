/**
 * ejercicio1.js — Sistema de registro académico
 * crearEstudiante(nombre, ...notas)
 *   a. try...catch para validar que todas las notas sean números
 *   b. destructuración para separar la primera nota del resto
 *   c. objeto inmutable con nombre, primera nota, promedio del resto y total
 */
import { hacerInmutable } from "./utilidades.js";

export function crearEstudiante(nombre, ...notas) {
  try {
    if (typeof nombre !== "string" || nombre.trim() === "") {
      throw new Error("El nombre es obligatorio y debe ser un texto válido.");
    }

    if (notas.length === 0) {
      throw new Error("Debe registrar al menos una nota.");
    }

    // a. Validación de que todas las notas sean números (ciclo for, sin métodos)
    for (let i = 0; i < notas.length; i++) {
      if (typeof notas[i] !== "number" || isNaN(notas[i])) {
        throw new Error(
          "La nota en la posición " + i + " no es un número válido: " + notas[i]
        );
      }
      if (notas[i] < 0 || notas[i] > 5) {
        throw new Error(
          "La nota en la posición " + i + " está fuera del rango 0 a 5: " + notas[i]
        );
      }
    }

    // b. Destructuración: primera nota separada del resto
    const [primeraNota, ...resto] = notas;

    // Promedio del resto calculado con ciclo for
    let promedioResto = 0;
    if (resto.length > 0) {
      let suma = 0;
      for (let i = 0; i < resto.length; i++) {
        suma += resto[i];
      }
      promedioResto = Number((suma / resto.length).toFixed(2));
    }

    // c. Objeto inmutable (sin Object.freeze)
    return hacerInmutable({
      nombre: nombre.trim(),
      primeraNota: primeraNota,
      promedioResto: promedioResto,
      totalNotas: notas.length,
      validacion: true,
    });
  } catch (error) {
    return hacerInmutable({
      error: error.message,
      validacion: false,
    });
  }
}

/**
 * Ejecuta el ejercicio pidiendo los datos al usuario mediante prompt.
 * @returns {Object} resultado para mostrar en pantalla
 */
export function ejecutarEjercicio1() {
  const nombre = prompt("Ejercicio 1 — Nombre del estudiante:");
  if (nombre === null) {
    return { cancelado: true };
  }

  const notas = [];
  let continuar = true;

  while (continuar) {
    const entrada = prompt(
      "Nota " + (notas.length + 1) + " (deje vacío para terminar):"
    );

    if (entrada === null || entrada.trim() === "") {
      continuar = false;
    } else {
      // Se guarda como número; si el usuario escribe texto quedará NaN
      // y la validación del try...catch lo detectará.
      const valor = entrada.trim() === "" ? NaN : Number(entrada);
      notas[notas.length] = isNaN(valor) ? entrada.trim() : valor;
    }
  }

  const estudiante = crearEstudiante(nombre, ...notas);

  return {
    titulo: "Ejercicio 1 — Sistema de registro académico",
    notasIngresadas: notas,
    resultado: estudiante,
  };
}
