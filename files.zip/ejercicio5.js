/**
 * ejercicio5.js — Motor de configuración avanzada
 * configFinal(...configs)
 *   a. recibe múltiples configuraciones usando rest
 *   b. spread para mezclarlas en un objeto final sin mutar ninguna
 *   c. try...catch para validar que cada elemento sea un objeto
 *   d. retorna el objeto final con la propiedad validacion (true / false)
 */
import { hacerInmutable, esObjetoPlano } from "./utilidades.js";

export const baseConfig = { modo: "producción", lenguaje: "es", nivel: 1 };
export const extraConfig = { nivel: 2, tema: "oscuro" };

export function configFinal(...configs) {
  try {
    // a + c. Validación de cada configuración recibida por rest
    if (configs.length === 0) {
      throw new Error("Debe enviar al menos una configuración.");
    }

    for (let i = 0; i < configs.length; i++) {
      if (esObjetoPlano(configs[i]) === false) {
        throw new Error(
          "La configuración en la posición " +
            i +
            " no es un objeto válido. Se recibió: " +
            typeof configs[i]
        );
      }
    }

    // b. Mezcla con spread: cada vuelta genera un objeto nuevo
    let resultado = {};
    for (let i = 0; i < configs.length; i++) {
      resultado = { ...resultado, ...configs[i] };
    }

    // d. Objeto final inmutable con la marca de validación
    return hacerInmutable({
      ...resultado,
      configuracionesAplicadas: configs.length,
      validacion: true,
    });
  } catch (error) {
    return hacerInmutable({
      error: error.message,
      validacion: false,
    });
  }
}

export function ejecutarEjercicio5() {
  const opcion = prompt(
    "Ejercicio 5 — Motor de configuración\n\n" +
      "1. Mezclar baseConfig + extraConfig\n" +
      "2. Agregar una configuración propia\n" +
      "3. Provocar un error (enviar un dato que no es objeto)\n\n" +
      "Digite 1, 2 o 3:"
  );

  if (opcion === null) {
    return { cancelado: true };
  }

  let resultado;

  if (opcion.trim() === "2") {
    const clave = prompt("Nombre de la propiedad (ejemplo: tema):");
    const valor = prompt("Valor de la propiedad (ejemplo: claro):");

    if (clave === null || valor === null || clave.trim() === "") {
      resultado = configFinal(baseConfig, extraConfig);
    } else {
      const propia = {};
      propia[clave.trim()] = valor;
      resultado = configFinal(baseConfig, extraConfig, propia);
    }
  } else if (opcion.trim() === "3") {
    resultado = configFinal(baseConfig, "no soy un objeto", extraConfig);
  } else {
    resultado = configFinal(baseConfig, extraConfig);
  }

  return {
    titulo: "Ejercicio 5 — Motor de configuración avanzada",
    baseConfigOriginal: baseConfig,
    extraConfigOriginal: extraConfig,
    resultado: resultado,
  };
}
