/**
 * ejercicio2.js — Fusión de catálogos digitales
 * fusionarCatalogos(a, b)
 *   a. try...catch para validar que ambos parámetros sean arreglos
 *   b. spread para fusionarlos sin modificar los originales
 *   c. retorna un catálogo nuevo ordenado por precio ascendente
 *
 * El ordenamiento se hace con el algoritmo de burbuja porque
 * no se permite usar el método sort().
 */
import { hacerInmutable, copiarArreglo } from "./utilidades.js";

export const catalogoA = [
  { id: 1, nombre: "Curso JavaScript", precio: 40 },
  { id: 2, nombre: "Curso HTML", precio: 35 },
];

export const catalogoB = [{ id: 3, nombre: "Curso CSS", precio: 30 }];

export function fusionarCatalogos(a, b) {
  try {
    // a. Validación de tipos
    if (Array.isArray(a) === false) {
      throw new Error("El primer parámetro no es un arreglo válido.");
    }
    if (Array.isArray(b) === false) {
      throw new Error("El segundo parámetro no es un arreglo válido.");
    }

    // b. Spread: se crea un arreglo nuevo, los originales quedan intactos
    const fusionado = [...a, ...b];

    // Validación del contenido con ciclo for
    for (let i = 0; i < fusionado.length; i++) {
      const item = fusionado[i];
      if (typeof item !== "object" || item === null) {
        throw new Error("El elemento en la posición " + i + " no es un objeto.");
      }
      if (typeof item.precio !== "number" || isNaN(item.precio)) {
        throw new Error(
          "El elemento en la posición " + i + " no tiene un precio numérico."
        );
      }
    }

    // c. Ordenamiento burbuja ascendente por precio (sin sort)
    const ordenado = copiarArreglo(fusionado);
    for (let i = 0; i < ordenado.length - 1; i++) {
      for (let j = 0; j < ordenado.length - 1 - i; j++) {
        if (ordenado[j].precio > ordenado[j + 1].precio) {
          const temporal = ordenado[j];
          ordenado[j] = ordenado[j + 1];
          ordenado[j + 1] = temporal;
        }
      }
    }

    // Cada curso se copia con spread y se vuelve inmutable
    const resultado = [];
    for (let i = 0; i < ordenado.length; i++) {
      resultado[i] = hacerInmutable({ ...ordenado[i] });
    }

    return hacerInmutable({
      catalogo: hacerInmutable(resultado),
      totalCursos: resultado.length,
      validacion: true,
    });
  } catch (error) {
    return hacerInmutable({
      error: error.message,
      validacion: false,
    });
  }
}

export function ejecutarEjercicio2() {
  const opcion = prompt(
    "Ejercicio 2 — Fusión de catálogos\n\n" +
      "1. Usar los catálogos de ejemplo\n" +
      "2. Provocar un error (enviar un dato que no es arreglo)\n\n" +
      "Digite 1 o 2:"
  );

  if (opcion === null) {
    return { cancelado: true };
  }

  let resultado;

  if (opcion.trim() === "2") {
    resultado = fusionarCatalogos(catalogoA, "esto no es un arreglo");
  } else {
    resultado = fusionarCatalogos(catalogoA, catalogoB);
  }

  return {
    titulo: "Ejercicio 2 — Fusión de catálogos digitales",
    catalogoAOriginal: catalogoA,
    catalogoBOriginal: catalogoB,
    resultado: resultado,
  };
}
