/**
 * index.js — ARCHIVO BARRIL (barrel file)
 * Centraliza todas las exportaciones de la carpeta modulos para que
 * app.js pueda importar desde un único punto de entrada.
 *
 * Sin el barril:
 *   import { ejecutarEjercicio1 } from "./modulos/ejercicio1.js";
 *   import { ejecutarEjercicio2 } from "./modulos/ejercicio2.js";
 *   ...
 *
 * Con el barril:
 *   import { ejecutarEjercicio1, ejecutarEjercicio2 } from "./modulos/index.js";
 */

// Utilidades compartidas
export {
  hacerInmutable,
  copiarArreglo,
  unirTexto,
  esObjetoPlano,
} from "./utilidades.js";

// Ejercicio 1 — Sistema de registro académico
export { crearEstudiante, ejecutarEjercicio1 } from "./ejercicio1.js";

// Ejercicio 2 — Fusión de catálogos digitales
export {
  fusionarCatalogos,
  ejecutarEjercicio2,
  catalogoA,
  catalogoB,
} from "./ejercicio2.js";

// Ejercicio 3 — Procesamiento de compras
export { procesarCompra, ejecutarEjercicio3 } from "./ejercicio3.js";

// Ejercicio 4 — Informe de estadísticas deportivas
export { estadisticas, ejecutarEjercicio4, jugadores } from "./ejercicio4.js";

// Ejercicio 5 — Motor de configuración avanzada
export {
  configFinal,
  ejecutarEjercicio5,
  baseConfig,
  extraConfig,
} from "./ejercicio5.js";
